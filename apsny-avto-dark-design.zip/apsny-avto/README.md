# Apsny Avto — MVP

Responsive PWA-style web app for car listings in Abkhazia. Includes catalog, search, city/brand filters, Supabase email authentication, photo upload, listing submission and moderation-ready statuses.

## Important status
This is a deployable MVP starter, not a live production marketplace yet. Demo cards appear until Supabase is configured. Real listings require a Supabase project, SQL setup, environment variables, and a deployed website. Native App Store / Google Play packages are not included; the responsive web app can be added to the phone home screen.

## 1. Supabase
1. Open your Supabase project.
2. SQL Editor → New query.
3. Paste and run `supabase/schema.sql`.
4. In Project Settings → API, copy Project URL and the publishable/anon key.
5. In Authentication → Providers, ensure Email is enabled.
6. Create your account in the app, then in Authentication → Users copy your user UUID.
7. Replace `YOUR_USER_UUID` in the final admin SQL comment and run that statement to grant your account moderation access.

Keep the `service_role` / secret key private. The website only uses the publishable/anon key.

## 2. Deploy on Vercel
1. Upload this project to a GitHub repository.
2. Import that repository in Vercel.
3. Framework preset: Vite. Build command: `npm run build`. Output directory: `dist`.
4. Add environment variables:
   - `VITE_SUPABASE_URL` = Project URL
   - `VITE_SUPABASE_ANON_KEY` = publishable/anon key
5. Deploy.

## 3. Local development
```bash
npm install
cp .env.example .env
# Fill .env with Supabase URL and publishable/anon key
npm run dev
```

## 4. Install on iPhone
After deployment, open the site in Safari → Share → Add to Home Screen.

## 5. Before public launch
Add terms/privacy pages, a reporting flow, stronger anti-spam controls, phone verification if appropriate, image moderation, backups, and test the RLS policies. Do not publish private keys. Review legal/privacy requirements for your region.
