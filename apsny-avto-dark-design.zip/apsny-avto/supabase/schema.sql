-- Apsny Avto database setup. Run once in Supabase SQL Editor.
create table if not exists public.cars (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  brand text not null,
  model text not null,
  year integer not null check (year between 1950 and 2035),
  price numeric(12,2) not null check (price > 0),
  city text not null default 'Сухум',
  description text,
  image_urls text[] not null default '{}',
  phone text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);
-- Compatibility with the earlier starter table that may already exist.
alter table public.cars add column if not exists owner_id uuid references auth.users(id) on delete cascade;
alter table public.cars enable row level security;

create table if not exists public.apsny_admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.apsny_admins enable row level security;

create or replace function public.is_apsny_admin()
returns boolean language sql stable security definer
set search_path = public
as $$ select exists(select 1 from public.apsny_admins where user_id = auth.uid()); $$;

drop policy if exists "Public can read approved cars" on public.cars;
create policy "Public can read approved cars" on public.cars
for select using (status = 'approved' or owner_id = auth.uid() or public.is_apsny_admin());

drop policy if exists "Signed in users can submit cars" on public.cars;
create policy "Signed in users can submit cars" on public.cars
for insert to authenticated with check (owner_id = auth.uid() and status = 'pending');

drop policy if exists "Owners can edit pending cars" on public.cars;
create policy "Owners can edit pending cars" on public.cars
for update to authenticated
using (owner_id = auth.uid() and status = 'pending')
with check (owner_id = auth.uid() and status = 'pending');

drop policy if exists "Admins can moderate cars" on public.cars;
create policy "Admins can moderate cars" on public.cars
for all to authenticated
using (public.is_apsny_admin())
with check (public.is_apsny_admin());

drop policy if exists "Admins table not readable by public" on public.apsny_admins;
create policy "Admins table not readable by public" on public.apsny_admins
for select to authenticated using (user_id = auth.uid());

-- Create a public storage bucket for listing photos.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('car-photos', 'car-photos', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists "Public can view car photos" on storage.objects;
create policy "Public can view car photos" on storage.objects
for select using (bucket_id = 'car-photos');

drop policy if exists "Users upload own car photos" on storage.objects;
create policy "Users upload own car photos" on storage.objects
for insert to authenticated
with check (bucket_id = 'car-photos' and (storage.foldername(name))[1] = auth.uid()::text);

-- After creating your own account, replace YOUR_USER_UUID below with the UUID
-- shown in Authentication > Users, then run this separately to grant admin access:
-- insert into public.apsny_admins(user_id) values ('YOUR_USER_UUID');
